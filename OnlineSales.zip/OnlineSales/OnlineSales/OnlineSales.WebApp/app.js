﻿/// <reference path="angular.js" />
(function () {
    var app =
        angular.module('onlineSales',
                ["ui.router",
                ]);
    app.config(["$stateProvider",
                "$urlRouterProvider",
    function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('Home/')
        $stateProvider
                .state("home", {
                    url: '/forum',
                    templateUrl: "app/modules/Home/home.html",
                    controller: "homeController"
                })
            .state("account", {
                url: '/account',
                abstract: true,
                templateUrl: "app/modules/Account/accountIndex.html"
            })
                  .state("account.login", {
                      url: '/login',
                      templateUrl: "app/modules/Account/loginPage.html",
                      controller: "homeController"
                  })
                .state("account.forgotPassword", {
                    url: '/forgotpassword',
                    templateUrl: "app/modules/Account/forgotPassword.html",
                })

        //.state('forum.topics', {
        //    url: '/topics/{CategoryName}',
        //    templateUrl: "/Views/topicTable.html",
        //    controller: "topicTableController",
        //    params: {
        //        CategoryID: null
        //    }
        //})
        //.state('forum.empty', {
        //    url: '/',
        //    templateUrl: "/Views/topicTable.html",
        //    controller: "topicTableController",

        //})
        //.state('topicDetails', {
        //    url: '/topicDetails/{TopicName}',
        //    templateUrl: "/Views/topicDetails.html",
        //    controller: "topicDetailsController",
        //    params: {
        //        Topic: null
        //    }
        //})
        ;
    }])

}());