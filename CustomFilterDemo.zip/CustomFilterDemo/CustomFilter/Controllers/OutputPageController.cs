﻿using CustomFilterDemo.CustomAttributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CustomFilter.Controllers
{
    [SystemAdminFilter]
    public class OutputPageController : Controller
    {
        // GET: OutputPage
        public string Index()
        {
            return "your authorized to this page";
        }
    }
}