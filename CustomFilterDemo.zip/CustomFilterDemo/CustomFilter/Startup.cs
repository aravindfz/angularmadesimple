﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CustomFilter.Startup))]
namespace CustomFilter
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
